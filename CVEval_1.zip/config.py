"""
Configuration for the CV evaluation Flask app.

Add your OpenAI API token to OPENAI_API_KEY before running the server.
This file stays on the server and is never exposed to the browser.
"""

# OpenAI API token (replace with your actual token)
OPENAI_API_KEY = "<Your OpenAI API key here>"

# Model name for the ChatGPT API. gpt-4o-mini keeps cost low and quality high.
OPENAI_MODEL = "gpt-4o-mini"

# Maximum upload size (in bytes). 5 MB is plenty for typical CVs.
MAX_CONTENT_LENGTH = 5 * 1024 * 1024

# Allowed file extensions for uploads
ALLOWED_EXTENSIONS = {"pdf"}

# Optional: absolute path to the Tesseract executable (needed on Windows if it
# is not on PATH). Example: r"C:\Program Files\Tesseract-OCR\tesseract.exe"
TESSERACT_CMD = r""

# Optional: path to the Poppler /bin folder for pdf2image on Windows.
# Example: r"C:\poppler-24.02.0\Library\bin"
POPPLER_PATH = r""

# OCR tuning
OCR_DPI = 800          # higher = better OCR, slower
OCR_MAX_PAGES = 5      # cap pages to protect resources
